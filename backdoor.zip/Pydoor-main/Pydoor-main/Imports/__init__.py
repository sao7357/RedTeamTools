import os
import re
import uuid
import json
import socket
import psutil
import base64
import logging
import platform
import subprocess
from cryptography.fernet import Fernet