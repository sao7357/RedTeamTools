import express from 'express';
import { logger as expressLogger } from 'express-winston';

import { logger, loggerOptions } from './logger.js';

import { router as aboutRouter } from './routes/about.js';
import { router as credentialsRouter } from './routes/credentials.js';

const app = express();

app.use(express.json());
app.use(expressLogger(loggerOptions));
app.use('/credentials', credentialsRouter);
app.use('/about', aboutRouter)

const port = 1337;

app.listen(port);

logger.info(`Sudont server started at port ${port}`);