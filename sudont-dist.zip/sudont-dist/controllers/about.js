import env from 'process';

/**
 * Handle a /about call.
 * 
 * @param {Request} req 
 * @param {Response} res 
 */
export function about(req, res) {
    if (env.NODE_ENV === 'production') {
        res.send("wouldn't you like to know");
    } else {
        const info = { version: '0.1.0' };
        res.send(info);
    }
}