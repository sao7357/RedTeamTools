import { logger } from '../logger.js';

/**
 * Handle a /credentials call.
 * 
 * @param {Request} req 
 * @param {Response} res 
 */
export function credentials(req, res) {
    const { user, password } = req.body;

    if (!user || !password) {
        res.sendStatus(400);
        return;
    }

    res.sendStatus(200);

    logger.info(`Received credentials: ${user} - ${password}`);
}