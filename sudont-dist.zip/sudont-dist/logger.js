import { createLogger, format, transports } from "winston";

export const loggerOptions = {
    level: 'silly',
    format: format.cli(),
    transports: [
        new transports.File({ filename: 'sudont.log', level: 'info', format: format.json() }),
        new transports.Console({ level: 'silly', format: format.cli() }),
    ],
};

export const logger = createLogger(loggerOptions);