import express from 'express';

import { about } from "../controllers/about.js";

export const router = express.Router();

/**
 * Return information about the application (or not)
 * 
 * @endpoint /about
 * @name about
 * @version v1
 * @since v1
 * @description Pretty much just used to check if the server is alive
 */
router.get('/', about);