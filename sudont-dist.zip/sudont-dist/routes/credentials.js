import express from 'express';

import { credentials } from "../controllers/credentials.js";

export const router = express.Router();

/**
 * Transmit login credentials to the sudont server.
 * 
 * @endpoint /credentials
 * @name credentials
 * @version v1
 * @since v1
 * @description Used to upload credentials
 * 
 * @example
 * {
 *     "user": "cdf",
 *     "password": "hunter2"
 * }
 */
router.post('/', credentials);