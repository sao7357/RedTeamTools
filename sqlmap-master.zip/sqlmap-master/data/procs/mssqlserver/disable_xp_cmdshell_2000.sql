EXEC master..sp_dropextendedproc 'xp_cmdshell'
